import Route from '@ember/routing/route';

export default class TransactionsRoute extends Route {}
