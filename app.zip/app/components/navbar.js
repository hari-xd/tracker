import Component from '@glimmer/component';
import { service } from '@ember/service';

export default class NavabarComponent extends Component {
  @service router;
}
