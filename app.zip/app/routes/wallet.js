import Route from '@ember/routing/route';

export default class WalletRoute extends Route {}
