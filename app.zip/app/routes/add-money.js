import Route from '@ember/routing/route';

export default class AddMoneyRoute extends Route {}
